#include <iostream>
#include <iomanip>
using namespace std;

int main() 
{
    float valor = 7.123456;

    cout << setprecision(2) << valor << endl;
    cout << setprecision(3) << valor << endl;
    cout << setprecision(4) << valor << endl;
    cout << setprecision(5) << valor << endl;
    cout << setprecision(6) << valor << endl;
    cout << setprecision(7) << valor << endl;

    return 0;
}