#include <iostream>
using namespace std;

int main()
{
    const double PI = 3.1416;
    double radio, longitud, area;

    cout << "Ingrese el radio: ";
    cin >> radio;

    longitud = 2 * PI * radio;
    area = PI * radio * radio;

    cout << "Longitud de la circunferencia: " << longitud << endl;
    cout << "Area del circulo: " << area << endl;

    return 0;
}