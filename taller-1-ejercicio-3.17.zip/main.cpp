#include <iostream>
using namespace std;

int main()
{
    int anyo, A, B, C, D, E, N;

    cout << "Ingrese el anyo: ";
    cin >> anyo;

    A = anyo % 19;
    B = anyo % 4;
    C = anyo % 7;
    D = (19 * A + 24) % 30;
    E = (2 * B + 4 * C + 6 * D + 5) % 7;
    N = 22 + D + E;

    if (N <= 31)
        cout << "Domingo de Pascua: " << N << " de marzo" << endl;
    else
        cout << "Domingo de Pascua: " << (N - 31) << " de abril" << endl;

    return 0;
}