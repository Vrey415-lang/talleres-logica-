#include <iostream>
using namespace std;

int main() 
{
    int mes, dias;

    cout << "Ingrese el numero del mes (1-12): ";
    cin >> mes;

    switch (mes) {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            dias = 31;
            break;
        case 4: case 6: case 9: case 11:
            dias = 30;
            break;
        case 2:
            dias = 28;
            break;
        default:
            cout << "Mes invalido" << endl;
            return 0;
    }

    cout << "El mes " << mes << " tiene " << dias << " dias." << endl;

    return 0;
}