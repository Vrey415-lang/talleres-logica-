#include <iostream>
using namespace std;

int main() {
    char c;

    cout << "Ingrese un caracter: ";
    cin >> c;

    if (c >= 'A' && c <= 'Z')
        cout << "Es una letra mayuscula" << endl;
    else if (c >= 'a' && c <= 'z')
        cout << "Es una letra minuscula" << endl;
    else if (c >= '0' && c <= '9')
        cout << "Es un digito" << endl;
    else if (c == '.' || c == ',' || c == ';' || c == ':' || c == '!' || c == '?')
        cout << "Es un signo de puntuacion" << endl;
    else
        cout << "Es un caracter especial" << endl;

    return 0;
}